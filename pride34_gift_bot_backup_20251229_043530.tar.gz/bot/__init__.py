"""Bot package initialization."""
