"""Test script to debug photo handling."""
import asyncio
import logging
from pathlib import Path

# Configure detailed logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


async def test_photo_processing():
    """Test the photo processing flow."""
    logger.info("=== STARTING PHOTO PROCESSING TEST ===")

    # Test 1: Check if OpenCV works
    try:
        import cv2
        logger.info(f"✓ OpenCV version: {cv2.__version__}")

        # Check cascade classifier
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        face_cascade = cv2.CascadeClassifier(cascade_path)

        if face_cascade.empty():
            logger.error("✗ Face cascade classifier failed to load!")
        else:
            logger.info(f"✓ Face cascade loaded from: {cascade_path}")
    except Exception as e:
        logger.error(f"✗ OpenCV error: {e}")
        return

    # Test 2: Check directories
    try:
        from config import settings
        logger.info(f"USER_PHOTOS_DIR: {settings.USER_PHOTOS_DIR}")
        logger.info(f"GENERATED_PHOTOS_DIR: {settings.GENERATED_PHOTOS_DIR}")
        logger.info(f"IMAGES_DIR: {settings.IMAGES_DIR}")

        settings.create_directories()
        logger.info("✓ Directories created")
    except Exception as e:
        logger.error(f"✗ Directory creation error: {e}")
        return

    # Test 3: Check ImageProcessor
    try:
        from services.image_processor import ImageProcessor
        processor = ImageProcessor()
        logger.info("✓ ImageProcessor initialized")

        # Check templates
        template_dir = settings.IMAGES_DIR / "new_templates"
        if template_dir.exists():
            templates = list(template_dir.glob("*.png"))
            logger.info(f"✓ Found {len(templates)} templates in {template_dir}")
            for t in templates[:5]:  # Show first 5
                logger.info(f"  - {t.name}")
        else:
            logger.warning(f"⚠ Template directory not found: {template_dir}")

    except Exception as e:
        logger.error(f"✗ ImageProcessor error: {e}")
        import traceback
        traceback.print_exc()
        return

    # Test 4: Check database connection
    try:
        from database.engine import async_session_maker, init_db

        # Initialize DB
        await init_db()
        logger.info("✓ Database initialized")

        # Test session
        async with async_session_maker() as session:
            logger.info("✓ Database session created")

    except Exception as e:
        logger.error(f"✗ Database error: {e}")
        import traceback
        traceback.print_exc()
        return

    # Test 5: Simulate photo handler with mock data
    logger.info("\n=== SIMULATING PHOTO HANDLER ===")

    # Find a test photo if available
    test_photo = None
    user_photos_dir = Path(settings.USER_PHOTOS_DIR)

    if user_photos_dir.exists():
        photos = list(user_photos_dir.glob("*.jpg")) + list(user_photos_dir.glob("*.png"))
        if photos:
            test_photo = photos[0]
            logger.info(f"✓ Found test photo: {test_photo}")

    if test_photo and test_photo.exists():
        # Test face detection
        try:
            img = cv2.imread(str(test_photo))
            if img is None:
                logger.error(f"✗ Failed to read image: {test_photo}")
            else:
                logger.info(f"✓ Image loaded: {img.shape}")

                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, 1.1, 4)

                logger.info(f"✓ Detected {len(faces)} face(s)")

                if len(faces) > 0:
                    logger.info("  Face detection PASSED - would proceed to generation")

                    # Test image generation (dry run)
                    try:
                        logger.info("  Testing image generation...")
                        test_user_id = 999999
                        generated_path = await processor.create_christmas_figure(
                            user_photo_path=test_photo,
                            gender="male",
                            user_id=test_user_id
                        )
                        logger.info(f"✓ Image generated successfully: {generated_path}")

                    except Exception as gen_error:
                        logger.error(f"✗ Generation error: {gen_error}")
                        import traceback
                        traceback.print_exc()
                else:
                    logger.warning("  No faces detected - would ask user to resend photo")

        except Exception as e:
            logger.error(f"✗ Face detection error: {e}")
            import traceback
            traceback.print_exc()
    else:
        logger.warning("⚠ No test photo available. Please upload a photo first.")

    logger.info("\n=== TEST COMPLETE ===")


if __name__ == "__main__":
    asyncio.run(test_photo_processing())
