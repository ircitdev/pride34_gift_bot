#!/usr/bin/env python3
"""Test certificate generation."""
import asyncio
from pathlib import Path
from services.certificate_generator import CertificateGenerator
from config import settings


async def main():
    """Test certificate generation."""
    print("Testing certificate generation...")
    print(f"QUIZ_END_DATE: {settings.QUIZ_END_DATE}")
    print(f"CERTIFICATE_NAME_Y: {settings.CERTIFICATE_NAME_Y}")
    print(f"CERTIFICATE_DATE_Y: {settings.CERTIFICATE_DATE_Y}")
    print(f"CERTIFICATE_FONT_SIZE: {settings.CERTIFICATE_FONT_SIZE}")
    print()

    generator = CertificateGenerator()

    try:
        cert_path = await generator.generate_certificate(
            user_id=999999,
            user_name="Тестовый Пользователь",
            expiry_date=settings.QUIZ_END_DATE
        )

        print(f"✅ Certificate generated: {cert_path}")
        print(f"   File exists: {cert_path.exists()}")
        print(f"   File size: {cert_path.stat().st_size if cert_path.exists() else 0} bytes")

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
