# Система sharing и реферальных ссылок

## Обзор

Пользователи могут делиться результатами квиза в социальных сетях и с друзьями через реферальные ссылки.

## Функциональность

### 1. Кнопки sharing после получения открытки

После генерации новогодней открытки пользователь видит 3 кнопки:

1. **📱 Поделиться в VK** - открывает VK с предзаполненной ссылкой на бота
2. **✈️ Поделиться в Telegram** (только для Premium пользователей) - нативный sharing в Telegram
3. **🎁 Рассказать друзьям** - открывает выбор контактов для отправки реферальной ссылки

### 2. Реферальная система

#### Формат реферальной ссылки

```
https://t.me/PRIDE34_GIFT_BOT?start=ref{user_id}
```

Где `{user_id}` - Telegram ID пользователя, который делится ссылкой.

#### Как это работает

1. Пользователь проходит квиз и получает открытку
2. Нажимает "🎁 Рассказать друзьям"
3. Появляется кнопка "📤 Выбрать друзей и отправить"
4. При нажатии открывается inline mode с выбором контактов
5. Пользователь выбирает друга и отправляет сообщение с реферальной ссылкой
6. Друг переходит по ссылке `/start ref{user_id}`
7. Бот сохраняет `referrer_id` в базу данных
8. Когда друг дошёл до получения открытки, в топике форума появляется запись:

```
🎁 Реферал от: Pride GIFT ID 12345
👉 Перейти к топику реферера
```

## Технические детали

### 1. База данных

**Таблица `users`:**
- `referrer_id` (BigInteger, nullable, indexed) - ID пользователя, который пригласил
- `forum_topic_id` (Integer, nullable) - ID топика в форуме
- `pride_gift_id` (Integer, unique) - Уникальный Pride GIFT ID

### 2. Файлы

**handlers/inline.py** - обработчик inline mode для sharing
- `handle_inline_query()` - обрабатывает inline запросы
- Возвращает InlineQueryResultArticle с реферальной ссылкой

**handlers/photo.py**
- `handle_share_with_friends()` - обработчик кнопки "Рассказать друзьям"
- `handle_close_share_menu()` - возврат к основному меню sharing

**handlers/start.py**
- Парсит параметр `ref{id}` из `/start`
- Сохраняет `referrer_id` в базу

**bot/keyboards.py**
- `get_share_keyboard()` - клавиатура с кнопками sharing

**services/forum_service.py**
- `create_user_topic()` - создаёт топик в форуме
- Добавляет информацию о реферере с кликабельной ссылкой

**database/crud.py**
- `UserCRUD.set_referrer()` - устанавливает referrer_id
- `UserCRUD.generate_referral_link()` - генерирует реферальную ссылку

### 3. Inline Mode

#### Требования

Для работы inline mode нужно:
1. Включить inline mode в [@BotFather](https://t.me/BotFather)
2. Команда: `/setinline`
3. Placeholder (опционально): "Поделиться квизом с друзьями"

#### API используется

- `SwitchInlineQueryChosenChat` - открывает выбор контактов
- `InlineQuery` - обрабатывает inline запросы
- `InlineQueryResultArticle` - результат для отправки

#### Параметры SwitchInlineQueryChosenChat

```python
switch_inline = SwitchInlineQueryChosenChat(
    query=share_text,          # Предзаполненный текст
    allow_user_chats=True,     # Разрешить личные чаты
    allow_bot_chats=False,     # Запретить чаты с ботами
    allow_group_chats=False,   # Запретить группы
    allow_channel_chats=False  # Запретить каналы
)
```

### 4. Текст sharing сообщения

```
🎄 Привет! Я прошёл новогодний квиз от PRIDE Fitness и получил своё фитнес-предсказание на 2026 год!

Попробуй и ты — узнай, что тебя ждёт в новом году, и получи классное праздничное фото! 🎁

👉 https://t.me/PRIDE34_GIFT_BOT?start=ref123456
```

## User Flow

### Пользователь A (реферер)

1. Проходит квиз → получает открытку
2. Видит кнопки sharing
3. Нажимает "🎁 Рассказать друзьям"
4. Нажимает "📤 Выбрать друзей и отправить"
5. Выбирает контакт Пользователя B
6. Отправляет сообщение с реферальной ссылкой

### Пользователь B (реферал)

1. Получает сообщение от Пользователя A
2. Нажимает на ссылку `https://t.me/PRIDE34_GIFT_BOT?start=ref{A_user_id}`
3. Бот сохраняет `referrer_id = A_user_id` в базу
4. Проходит квиз → получает открытку
5. В топике форума появляется:
   - Pride GIFT ID Пользователя B
   - Ссылка "🎁 Реферал от: Pride GIFT ID {A_pride_gift_id}"
   - Кликабельная ссылка на топик Пользователя A

## Статистика реферралов (для админа)

В будущем можно добавить:
- Топ рефереров
- Количество приглашённых друзей для каждого пользователя
- Граф реферальной цепочки

## Примеры запросов к базе

### Получить всех рефералов пользователя

```sql
SELECT * FROM users WHERE referrer_id = 123456;
```

### Получить топ рефереров

```sql
SELECT
    referrer_id,
    COUNT(*) as referral_count
FROM users
WHERE referrer_id IS NOT NULL
GROUP BY referrer_id
ORDER BY referral_count DESC
LIMIT 10;
```

### Получить цепочку реферралов

```sql
WITH RECURSIVE referral_chain AS (
    -- Начальный пользователь
    SELECT id, referrer_id, username, 1 as level
    FROM users
    WHERE id = 123456

    UNION ALL

    -- Рекурсивно получаем всех рефералов
    SELECT u.id, u.referrer_id, u.username, rc.level + 1
    FROM users u
    INNER JOIN referral_chain rc ON u.referrer_id = rc.id
)
SELECT * FROM referral_chain;
```

## Настройки в .env

Не требуется дополнительных настроек. Система использует существующие:

- `BOT_TOKEN` - токен бота
- `FORUM_GROUP_ID` - ID форума для топиков

## Тестирование

### Локальное тестирование

1. Создать тестового пользователя A
2. Сгенерировать реферальную ссылку:
   ```python
   from database.crud import UserCRUD
   link = UserCRUD.generate_referral_link("PRIDE34_GIFT_BOT", 123456)
   print(link)
   ```
3. Открыть ссылку в другом аккаунте (Пользователь B)
4. Проверить, что `referrer_id` сохранился в базу
5. Дойти до получения открытки
6. Проверить топик в форуме - должна быть ссылка на реферера

### Проверка inline mode

1. В любом чате набрать `@PRIDE34_GIFT_BOT`
2. Должно появиться: "🎄 Поделиться новогодним квизом"
3. Нажать на результат
4. Сообщение должно содержать реферальную ссылку

## Возможные проблемы

### Inline mode не работает

**Причина:** Не включён inline mode в BotFather

**Решение:**
1. Написать [@BotFather](https://t.me/BotFather)
2. `/setinline`
3. Выбрать бота
4. Ввести placeholder (опционально)

### Не открывается выбор контактов

**Причина:** Ошибка в `SwitchInlineQueryChosenChat`

**Решение:** Проверить версию aiogram (должна быть 3.15+)

### Referrer_id не сохраняется

**Причина:** Пользователь уже существует в базе

**Решение:** `referrer_id` сохраняется только для новых пользователей при первом `/start`

## Changelog

### v1.0 (2024-12-29)

- ✅ Добавлена система реферральных ссылок
- ✅ Inline mode handler для sharing
- ✅ Кнопки VK и Telegram Premium sharing
- ✅ Интеграция с форумом (отображение реферера в топике)
- ✅ База данных: `referrer_id` в таблице users
- ❌ Убрана кнопка "Начать заново"
- ❌ Убрана кнопка Instagram (оставлена только VK)
