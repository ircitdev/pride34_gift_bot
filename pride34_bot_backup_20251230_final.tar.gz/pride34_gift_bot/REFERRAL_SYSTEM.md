# Реферальная система и социальный шеринг - Pride34 Gift Bot

**Дата внедрения:** 2025-12-29
**Версия:** 1.0.0
**Статус:** ✅ Развернуто в production

---

## Обзор

Реализована полная система рефералов с отслеживанием приглашенных пользователей и расширенными возможностями социального шеринга.

---

## Новый функционал

### 1. Социальный шеринг

После завершения квиза пользователь получает расширенную клавиатуру с кнопками:

- **📸 Поделиться в Instagram** - ссылка на Instagram PRIDE34
- **📤 Поделиться в VK** - шеринг в ВКонтакте
- **✈️ Поделиться в Telegram** - только для Telegram Premium пользователей
- **🎁 Рассказать друзьям** - реферальная ссылка с открытием списка контактов

### 2. Реферальная система

#### Как работает:

1. **Пользователь завершает квиз** → Получает кнопки шеринга
2. **Нажимает "🎁 Рассказать друзьям"** → Открывается список контактов Telegram
3. **Друг получает ссылку** → Формат: `https://t.me/PRIDE34_GIFT_BOT?start=ref{user_id}`
4. **Друг переходит по ссылке** → Система записывает `referrer_id` при регистрации
5. **Друг завершает квиз** → В топике форума отображается реферальная информация

#### Пример реферальной ссылки:
```
https://t.me/PRIDE34_GIFT_BOT?start=ref123456
```

---

## Изменения в базе данных

### Новое поле в таблице `users`:

```sql
referrer_id BIGINT NULL  -- ID пользователя, который пригласил
INDEX ix_users_referrer_id ON users(referrer_id)
```

### Миграция:

Файл: `migrate_add_referrer_id.py`

```bash
# Локально (для разработки):
python migrate_add_referrer_id.py

# На сервере:
ssh root@31.44.7.144 "cd /var/www/pride34_gift_bot && python3 migrate_add_referrer_id.py"
```

**Статус:** ✅ Выполнено на production

---

## Технические детали

### Модифицированные файлы:

#### 1. [database/models.py](database/models.py:26)
```python
referrer_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
```

#### 2. [database/crud.py](database/crud.py:156-176)

Добавлены методы:
- `set_referrer(session, user_id, referrer_id)` - сохранить реферера
- `generate_referral_link(bot_username, user_id)` - генерация ссылки

```python
def generate_referral_link(bot_username: str, user_id: int) -> str:
    return f"https://t.me/{bot_username}?start=ref{user_id}"
```

#### 3. [bot/keyboards.py](bot/keyboards.py:40-69)

Обновлена функция `get_share_keyboard()`:
```python
def get_share_keyboard(bot_username: str, user_id: int, has_premium: bool = False)
```

Параметры:
- `bot_username` - имя бота для реферальной ссылки
- `user_id` - ID пользователя для реферальной системы
- `has_premium` - флаг Telegram Premium (для условной кнопки)

#### 4. [handlers/start.py](handlers/start.py:19-56)

Обработка реферальных параметров:
```python
# Парсинг /start ref{referrer_id}
if message.text and len(message.text.split()) > 1:
    start_param = message.text.split()[1]
    if start_param.startswith("ref"):
        referrer_id = int(start_param[3:])
```

Логика:
- Проверяет существование реферера
- Сохраняет только для новых пользователей (не перезаписывает)
- Логирует реферальные переходы

#### 5. [handlers/photo.py](handlers/photo.py:176-289)

**Функция `send_final_result()`:**
- Получает username бота динамически через `bot.get_me()`
- Проверяет Telegram Premium статус
- Передает параметры в `get_share_keyboard()`

**Callback `handle_share_with_friends`:**
- Генерирует реферальную ссылку
- Создает сообщение для шеринга
- Использует `switch_inline_query` для открытия контактов

**Интеграция с форумом:**
- Получает информацию о реферере из БД
- Передает данные в `ForumService.create_user_topic()`

#### 6. [services/forum_service.py](services/forum_service.py:16-96)

Новые параметры:
```python
referrer_id: int = None
referrer_topic_id: int = None
referrer_pride_gift_id: int = None
```

Отображение в топике:
```python
if referrer_id and referrer_topic_id and referrer_pride_gift_id:
    topic_link = f"https://t.me/c/{str(settings.FORUM_GROUP_ID)[4:]}/{referrer_topic_id}"
    user_data_text += (
        f"\n🎁 Реферал от: Pride GIFT ID {referrer_pride_gift_id}\n"
        f"👉 Перейти к топику реферера\n"
    )
```

---

## Пример топика с рефералом

```
👨 Данные пользователя

Pride GIFT ID: 12345
Telegram ID: 987654321
Username: @example_user
Имя: Иван Иванов
Пол: Мужской

🎁 Реферал от: Pride GIFT ID 54321
👉 [Перейти к топику реферера]

Ответы на квиз:
...
```

---

## Требования

### Telegram Bot Settings:

⚠️ **ВАЖНО:** Для работы кнопки "Рассказать друзьям" необходимо включить **Inline Mode** в BotFather:

```
/mybots → @PRIDE34_GIFT_BOT → Bot Settings → Inline Mode → Turn on
```

Без этого `switch_inline_query` не будет работать!

---

## Тестирование

### Локальное тестирование:

1. Запустить бота локально
2. Пройти квиз до конца
3. Проверить наличие кнопок шеринга
4. Нажать "🎁 Рассказать друзьям"
5. Проверить открытие списка контактов

### Production тестирование:

1. Открыть бота: [@PRIDE34_GIFT_BOT](https://t.me/PRIDE34_GIFT_BOT)
2. Пройти квиз полностью
3. Получить фото с кнопками
4. Проверить все кнопки шеринга
5. Создать реферальную ссылку
6. Открыть в другом аккаунте
7. Проверить запись в БД
8. Проверить топик в форуме

---

## Логирование

### Ключевые логи для отслеживания:

```python
# При переходе по реферальной ссылке:
logger.info(f"User {user_id} came via referral from {referrer_id}")

# При сохранении реферера:
logger.info(f"Set referrer {referrer_id} for user {user_id}")

# При создании топика с рефералом:
logger.info(f"User {user_id} was referred by {referrer_id}")
```

Просмотр логов на сервере:
```bash
ssh root@31.44.7.144 "journalctl -u pride34-gift-bot.service -f | grep -i refer"
```

---

## Статистика рефералов

### SQL запросы для аналитики:

**Количество рефералов у пользователя:**
```sql
SELECT referrer_id, COUNT(*) as referrals_count
FROM users
WHERE referrer_id IS NOT NULL
GROUP BY referrer_id
ORDER BY referrals_count DESC;
```

**Топ-10 рефереров:**
```sql
SELECT
    u1.id,
    u1.pride_gift_id,
    u1.full_name,
    COUNT(u2.id) as referrals
FROM users u1
LEFT JOIN users u2 ON u2.referrer_id = u1.id
GROUP BY u1.id
HAVING referrals > 0
ORDER BY referrals DESC
LIMIT 10;
```

**Пользователи, пришедшие по рефералам:**
```sql
SELECT
    u.id,
    u.pride_gift_id,
    u.full_name,
    r.pride_gift_id as referrer_pride_id,
    r.full_name as referrer_name
FROM users u
JOIN users r ON u.referrer_id = r.id
WHERE u.referrer_id IS NOT NULL;
```

---

## Развертывание

### Последовательность действий:

```bash
# 1. Локальный коммит
git add .
git commit -m "Add referral system"

# 2. Push в GitHub
git push origin main

# 3. Загрузка на сервер
scp bot/keyboards.py database/crud.py database/models.py \
    handlers/start.py handlers/photo.py services/forum_service.py \
    migrate_add_referrer_id.py root@31.44.7.144:/var/www/pride34_gift_bot/

# 4. Миграция БД
ssh root@31.44.7.144 "cd /var/www/pride34_gift_bot && python3 migrate_add_referrer_id.py"

# 5. Перезапуск бота
ssh root@31.44.7.144 "systemctl restart pride34-gift-bot"

# 6. Проверка статуса
ssh root@31.44.7.144 "systemctl status pride34-gift-bot"
```

### Статус развертывания:

- ✅ GitHub: Commit `ebaabc3`
- ✅ Сервер: Файлы загружены
- ✅ База данных: Миграция выполнена
- ✅ Бот: Перезапущен, работает

---

## Известные ограничения

1. **Inline Mode требует активации** в BotFather
2. **Telegram Premium detection** - может быть `None` у некоторых пользователей
3. **Forum link format** - зависит от формата FORUM_GROUP_ID (с `-100` префиксом)
4. **Реферер перезапись** - система не позволяет изменить реферера после первой записи

---

## Будущие улучшения

- [ ] Админ-панель для просмотра статистики рефералов
- [ ] Награды/бонусы для топ-рефереров
- [ ] Email-уведомления рефереру о новых приглашенных
- [ ] Экспорт реферальной статистики в CSV
- [ ] Реферальные промокоды вместо числовых ID

---

## Контакты

**Разработчик:** Claude Code + @ircitdev
**Репозиторий:** https://github.com/ircitdev/pride34_gift_bot
**Бот:** [@PRIDE34_GIFT_BOT](https://t.me/PRIDE34_GIFT_BOT)
