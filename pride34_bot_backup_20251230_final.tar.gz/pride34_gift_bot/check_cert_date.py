from datetime import datetime

date_str = "15-01-2026"
date_obj = None
for fmt in ["%Y-%m-%d", "%d-%m-%Y"]:
    try:
        date_obj = datetime.strptime(date_str, fmt)
        print(f"Parsed with format {fmt}: {date_obj}")
        break
    except ValueError:
        continue

if date_obj:
    months_ru = {
        1: 'января', 2: 'февраля', 3: 'марта', 4: 'апреля',
        5: 'мая', 6: 'июня', 7: 'июля', 8: 'августа',
        9: 'сентября', 10: 'октября', 11: 'ноября', 12: 'декабря'
    }
    day = date_obj.day
    month_name = months_ru[date_obj.month]
    year = date_obj.year
    formatted_date = f"{day} {month_name} {year}"
    print(f"Formatted date: {formatted_date}")
